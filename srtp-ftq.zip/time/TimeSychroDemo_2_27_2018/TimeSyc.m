%% main
load testVelData.mat
% first plot
figure(1);
subplot(211); plot( (1:length(testVel2)) ./ 60 ,testVel2); grid on; ...
    xlabel('Time /s'); ylabel('velocity cm/s'); title('Data from camera');
subplot(212); plot( (1:length(testVel1)) ./ 60 ,testVel1); grid on; ...
    xlabel('Time /s'); ylabel('velocity cm/s'); title('Data from Motion Capture')

% process time sychro
[x,fval] = ga(@(x)calTime(x, testVel1, testVel2),2,[],[],[],[],[-200 0],[200 2],[],[1 2]);
T = x(1)
figure(2);

if T > 0
subplot(211); plot( (1:length(testVel2(T : end))) ./ 60 ,testVel2(T : end)); grid on; ...
    xlabel('Time /s'); ylabel('velocity cm/s'); title('Data from camera');
subplot(212); plot( (1:length(testVel1)) ./ 60 ,testVel1); grid on; ...
    xlabel('Time /s'); ylabel('velocity cm/s'); title('Data from Motion Capture')
else
subplot(211); plot( (1:length(testVel2)) ./ 60 ,testVel2); grid on; ...
    xlabel('Time /s'); ylabel('velocity cm/s'); title('Data from camera');
subplot(212); plot( (1:length(testVel1(-T : end))) ./ 60 ,testVel1(-T : end)); grid on; ...
    xlabel('Time /s'); ylabel('velocity cm/s'); title('Data from Motion Capture')
end

function res = calTime(x ,testVel1, testVel2)
    T = x(1); alpha = x(2);
    res = 0;
    % ��ȡ100֡��Ƭ��
    for i = 201 : 300
       res = res + ( testVel1(i) - alpha * testVel2(i + T) )^2;
    end
    res = res / 2 / 100;
end


