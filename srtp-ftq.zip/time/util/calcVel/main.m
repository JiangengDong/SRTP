%% time synchronization
% sm = (s1 + s2 + s3) / 3;
% sb and s4 is symmtric about sm
% which derive sb = 2 * sm - s4
load rawData.mat
velVision = calVel(VisionData);
MotiveBallData = [MotiveData(:, 1), 1000 * (2/3 * (MotiveData(:, 2:4) + ...
    MotiveData(:, 5:7) + MotiveData(:, 8:10)) - MotiveData(:, 11:13))  ];
motiveVel = calVel(MotiveBallData);



function vel = calVel(Data)
    len = length(Data);
    realLen = Data(len, 1) - Data(1, 1) + 1; 
    vel = zeros(1, realLen);
    lastVel = 0;
    % ��֡��������ǵò���
    for i = 1 : len-1
       thisVel = norm(Data(i+1, 2:4) - Data(i, 2:4)) / ((Data(i+1, 1) - Data(i, 1))/60);
        if (thisVel > 1000 )
            thisVel = lastVel;
        end
        lastVel = thisVel;
        for j = Data(i, 1) - Data(1, 1) + 1 : Data(i+1, 1) - Data(1, 1) 
            vel(j) = thisVel;
        end
    end
end
