function vel = calVel(Data)
    len = length(Data);
    realLen = Data(len, 1) - Data(1, 1) + 1; 
    vel = zeros(1, realLen);
    % ��֡��������ǵò���
    for i = 1 : len-1
       thisVel = norm(Data(i+1, 2:4) - Data(i, 2:4)) / ((Data(i+1, 1) - Data(i, 1))/60);
        if (thisVel > 1000)
            thisVel = lastVel;
        end
        lastVel = thisVel;
        for j = Data(i, 1) - Data(1, 1) + 1 : Data(i+1, 1) - Data(1, 1) 
            vel(j) = thisVel;
        end
    end
end