%% call all params
function err = calRotateMat2(x, data1, data2)
    % alpha, beta, gamma, t1, t2, t3
%     R1 = [[cos(x(1)) -sin(x(1)) 0 0]; [sin(x(1)) cos(x(1)) 0 0]; [0 0 1 0]; [0 0 0 1]];
%     R2 = [[1 0 0 0]; [0 cos(x(2)) -sin(x(2)) 0]; [0 sin(x(2)) cos(x(2)) 0]; [0 0 0 1]];
%     R3 = [[cos(x(3)) 0 sin(x(3)) 0]; [0 1 0 0]; [-sin(x(3)) 0 cos(x(3)) 0]; [0 0 0 1]];
    R = reshape(x, [4 4]);
    res =  R * [data1(:, 2:4), ones(size(data1, 1), 1)]' - [data2(:, 2:4), ones(size(data1, 1), 1)]'; % n-by-4 * 4-by-4 = n-by-4
    res = res';
    err = 0;
    for i = 1 : size(res, 1)
        err = err + norm(res(i, :))^2;
    end
end