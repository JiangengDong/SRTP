function vel = calVel(MidData)
    len = length(MidData);
    vel = zeros(1, len);
    for i = 1 : len-1
       vel(i) = norm(MidData(i+1, 2:4) - MidData(i, 2:4)) / ((MidData(i+1, 1) - MidData(i, 1))/60);
        if (vel(i) > 1000 && i >= 2)
            vel(i) = vel(i - 1);
        end
    end
end