function plotVisionData(start, endindex, VisionData)
    figure;
    for i = start:endindex
       scatter3(VisionData(i, 2), VisionData(i, 3), VisionData(i, 4), 'b'); 
        hold on
    end
    

end