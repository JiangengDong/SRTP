function plotMotiveTraj(start, endindex, MotiveData)
    for i = start : endindex
        scatter3(MotiveData(i, 2), MotiveData(i, 3), MotiveData(i, 4), 'b');
        hold on;
        scatter3(MotiveData(i, 5), MotiveData(i, 6), MotiveData(i, 7), 'b');
        scatter3(MotiveData(i, 8), MotiveData(i, 9), MotiveData(i, 10), 'b');
        plot3([MotiveData(i, 2), MotiveData(i, 5)], [MotiveData(i, 3), MotiveData(i, 6)],  [MotiveData(i, 4), MotiveData(i, 7)], 'r' );
        plot3([MotiveData(i, 8), MotiveData(i, 5)], [MotiveData(i, 9), MotiveData(i, 6)],  [MotiveData(i, 10), MotiveData(i, 7)], 'r' );
    end

end